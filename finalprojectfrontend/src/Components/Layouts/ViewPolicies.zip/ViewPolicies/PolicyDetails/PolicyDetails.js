import React, { useEffect, useState } from 'react'
import Navbar from '../../Navbar/Navbar';
import Footer from '../../Footer/Footer';
import { useNavigate, useParams } from 'react-router-dom';
import axios from 'axios';

const PolicyDetails = () => {
    const policyId = useParams().policyid
    const [policy, setPolicy] = useState([]);
    const [loading, setLoading] = useState(true);
    // const [planName,setPlanName] = useState()
    const [user, setUser] = useState({ username: "", role: "" });
    const { username, role } = useParams();
    const navigate = useNavigate()

    const [years, setYears] = useState('');
  const [totalInvestment, setTotalInvestment] = useState('');
  const [installmentMonths, setInstallmentMonths] = useState(3);
  const [installmentAmount, setInstallmentAmount] = useState('');
  const [profit, setProfit] = useState('');
  const [totalAmount, setTotalAmount] = useState('');

  useEffect(() => {
    if (username && role) {
      setUser({ username, role });
    }
  }, [role]);

    const getAllPolicy=async()=>{
        const resp = await axios.get(`http://localhost:8081/policy/get-id/${policyId}`)
      .then(response => {
        console.log(response);
        setPolicy(response.data);
        setLoading(false);
      })
      .catch(error => {
        console.error(error);
      });
      
    }

  useEffect(() => {
    getAllPolicy()
  }, [policyId]);

  if (loading) {
    return <div>Loading...</div>;
  }
  const handleYearsChange = (e) => {
    setYears(e.target.value);
  };

  const handleTotalInvestmentChange = (e) => {
    setTotalInvestment(e.target.value);
  };

  const handleInstallmentMonthsChange = (e) => {
    setInstallmentMonths(e.target.value);
  };

  
  const calculate = () => {
    const months = parseInt(years) * 12;
    const totalInstallments = months/installmentMonths;
    const installmentValue = parseFloat(totalInvestment) / totalInstallments;
    const profitValue = parseFloat(totalInvestment) * (policy.details.profit / 100);
    const totalValue = parseFloat(totalInvestment) + profitValue;

    setInstallmentAmount(installmentValue.toFixed(2));
    setProfit(profitValue.toFixed(2));
    setTotalAmount(totalValue.toFixed(2));
  };

  const handleSubmit = ()=>{
    navigate(`/payment/${user.username}/${user.role}`)
  }
  
  return (
    <>
    <div>
        <Navbar user={user} />
        <div class="container">
            <div class="row">
                <div class="col-md-6">
                    <div>
                        <h2>{policy.policyName}</h2>
                        <p>{policy.description}</p>
                    </div>
                </div>
            </div>
            
            <div class="row g-3 ms-3 me-3 mt-3 mb-3">
                <div class="col-12">
                    <h1 className='d-flex align-items-center justify-content-center'>Premium Details</h1>
                </div>
                <div class="col-md-6">
                    <h5 className="mt-2">Minimum Age:</h5>
                </div>
                <div class="col-md-6">
                <label for="exampleFormControlTextarea1" class="form-label" >{policy.details.miniAge}</label>
                </div>
                <div class="col-md-6">
                    <h5 className="mt-2">Maximum Age:</h5>
                </div>
                <div class="col-md-6">
                <label for="exampleFormControlTextarea1" class="form-label" >{policy.details.maxiAge}</label>
                </div>
                <div class="col-md-6">
                    <h5 className="mt-2">Maximum Amount:</h5>
                </div>
                <div class="col-md-6">
                <label for="exampleFormControlTextarea1" class="form-label" >{policy.details.maxiAmount}</label>
                </div>
                <div class="col-md-6">
                    <h5 className="mt-2">Minimum Age:</h5>
                </div>
                <div class="col-md-6">
                <label for="exampleFormControlTextarea1" class="form-label" >{policy.details.miniAmount}</label>
                </div>
                <div class="col-md-6">
                    <h5 className="mt-2">Maximum Policy-Term:</h5>
                </div>
                <div class="col-md-6">
                <label for="exampleFormControlTextarea1" class="form-label" >{policy.details.maxiInvestmentTime}</label>
                </div>
                <div class="col-md-6">
                    <h5 className="mt-2">Minimum Policy-Term:</h5>
                </div>
                <div class="col-md-6">
                <label for="exampleFormControlTextarea1" class="form-label" >{policy.details.miniInvestmentTime}</label>
                </div>
                <div class="col-md-6">
                    <h5 className="mt-2">Profit Ratio:</h5>
                </div>
                <div class="col-md-6">
                <label for="exampleFormControlTextarea1" class="form-label" >{policy.details.profit}</label>
                </div>
            </div>
            <div className="container mt-4">
      {/* <div className="row">
        <div className="col-md-6">
            <div className="mb-3">
                <label htmlFor="years" className="form-label">Number of years</label>
            </div>
        </div>
        <div className="col-md-6">
            <div className="mb-4">
                <input type="number" className="form-control" id="years" value={years} onChange={handleYearsChange} />
            </div>
        </div>
        <div className="col-md-6">
            <div className="mb-3">
                <label htmlFor="totalInvestment" className="form-label">Total investment amount</label>
            </div>
        </div>
        <div className="col-md-6">
            <div className="mb-4">
                <input type="number" className="form-control" id="totalInvestment" value={totalInvestment} onChange={handleTotalInvestmentChange} />
            </div>
        </div>
        <div className="col-md-6">
            <div className="mb-3">
                <label htmlFor="installmentMonths" className="form-label">Installment in months</label>
            </div>
        <div>
        <div className="col-md-6">
            <div className="mb-4">
                <select className="form-select" id="installmentMonths" value={installmentMonths} onChange={handleInstallmentMonthsChange}>
                <option value={3}>3 months</option>
                <option value={6}>6 months</option>
                <option value={12}>12 months</option>
                </select>
            </div>
        </div>
        </div>
        <div className='d-flex align-items-center justify-content-center'>
            <button className="btn btn-primary mb-3" onClick={calculate}>Calculate</button>
        </div> */}
        <div className='d-flex align-items-center justify-content-center w-100 mb-4'>
            <h1>Interest Calculator</h1>
        </div>
<div className="row">
        <div className="col-md-6">
            <div className="mb-3">
            <label htmlFor="years" className="form-label">Number of years</label>
            </div>
        </div>
        <div className="col-md-6">
            <div className="mb-3">
            <input type="number" className="form-control" id="years" value={years} onChange={handleYearsChange} />
            </div>
        </div>
        <div className="col-md-6">
            <div className="mb-3">
            <label htmlFor="totalInvestment" className="form-label">Total investment amount</label>
            </div>
        </div>
        <div className="col-md-6">
            <div className="mb-3">
            <input type="number" className="form-control" id="totalInvestment" value={totalInvestment} onChange={handleTotalInvestmentChange} />
            </div>
        </div>
        <div className="col-md-6">
            <div className="mb-3">
                <label htmlFor="installmentMonths" className="form-label">Installment in months</label>
            </div>
        </div>
        <div className="col-md-6">
            <div className="mb-3">
                <select className="form-select" id="installmentMonths" value={installmentMonths} onChange={handleInstallmentMonthsChange}>
                <option value={3}>3 months</option>
                <option value={6}>6 months</option>
                <option value={12}>12 months</option>
                </select>
            </div>
        </div>
        </div>
        <div className='d-flex align-items-center justify-content-center'>
            <button className="btn btn-primary mt-2 mb-4" onClick={calculate}>Calculate</button>
        </div>



            
        <div className="row">
        <div className="col-md-6">
            <div className="mb-3">
                <label htmlFor="installmentAmount" className="form-label">Installment amount</label>
            </div>
        </div>
        <div className="col-md-6">
            <div className="mb-3">
                <input type="text" className="form-control" id="installmentAmount" value={installmentAmount} disabled />
            </div>
        </div>
        <div className="col-md-6">
            <div className="mb-3">
                <label htmlFor="profit" className="form-label">Profit</label>
            </div>
        </div>
        <div className="col-md-6">
            <div className="mb-3">
                <input type="text" className="form-control" id="profit" value={profit} disabled />
            </div>
        </div>
        <div className="col-md-6">
            <div className="mb-3">
                <label htmlFor="totalAmount" className="form-label">Total amount</label>
            </div>
        </div>
        <div className="col-md-6">
            <div className="mb-3">
                <input type="text" className="form-control" id="profit" value={totalAmount} disabled />
            </div>
        </div>
        </div>
        </div>
        </div>
        </div>
        {user.role=='customer' &&
        <div className='d-flex align-items-center justify-content-center'>
            <button className="btn btn-danger mt-2 mb-4" onClick={handleSubmit}>Buy Policy</button>
        </div>
        }
    <Footer />
    </>
  )
}

export default PolicyDetails