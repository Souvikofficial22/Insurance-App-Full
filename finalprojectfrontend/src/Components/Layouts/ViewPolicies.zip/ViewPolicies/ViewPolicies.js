import axios from 'axios';
import React, { useEffect, useRef, useState } from 'react'
import { useParams } from 'react-router-dom'
import Navbar from '../Navbar/Navbar';
import Footer from '../Footer/Footer';

const ViewPolicies = () => {
    const planId = useParams().planid
    const [policies, setPolicies] = useState([]);
    const [loading, setLoading] = useState(true);
    const [planName,setPlanName] = useState()
    const [user, setUser] = useState({ username: "", role: "" });
    const { username, role } = useParams();

  useEffect(() => {
    if (username && role) {
      setUser({ username, role });
    }
  }, [role]);

    const getAllPolicies =async()=>{
        const resp = await axios.get(`http://localhost:8081/insuranceplan/get-id/${planId}`)
      .then(response => {
        console.log(response);
        setPlanName(response.data.insuranceType)
        setPolicies(response.data.policies);
        setLoading(false);
      })
      .catch(error => {
        console.error(error);
      });
      
    }

  useEffect(() => {
    getAllPolicies()
  }, [planId]);

  if (loading) {
    return <div>Loading...</div>;
  }
  
  return (
    <>
    <div>
        <Navbar user={user} />
        <div class="container">
            <div class="row">
                <div class="col-md-6">
                    <h2>{planName}</h2>
                    <div>
                        {policies.map(policy => (
                        <div key={policy.policyId}>
                            <h2><a href={`/viewpolicy/details/${policy.policyId}`}>{policy.policyName}</a></h2>
                            <p>{policy.description}</p>
                        </div>
                        ))}
                    </div>
                </div>
            </div>
        </div>
    </div>
    <Footer />
    </>
  )
}

export default ViewPolicies