import React from 'react'

const CommonNavbar = () => {
  return (
    <>
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
        <div class="container-fluid">
        <a class="navbar-brand" href="/"><h2>Secure-Insurane <i className='fab fa-typo3' /></h2></a>
        </div>
        <div class="collapse navbar-collapse" id="navbarSupportedContent">
      <ul class="navbar-nav me-auto mb-2 mb-lg-0">
      
        
      </ul>
    </div>
    </nav> 
    </>
  )
}

export default CommonNavbar