import React, { useRef, useState } from 'react'
import Navbar from '../../Layouts/Navbar/Navbar'
import { useNavigate, useParams } from 'react-router-dom'
import axios from 'axios'

const InsurancePlan = () => {

    const planName = useRef()
    const [status,setStatus] = useState(2) 
    const navigate = new useNavigate()
    
    const user = {
        username: useParams().username,
        role: useParams().role,
    }

    const handleSubmit= async (e)=>{
        e.preventDefault()
        if(status==2){
            alert("Please set a status")
            return
        }
        const token = localStorage.getItem("token")
        const resp= await axios.post(`http://localhost:8081/insuranceplan/save`, {
            "insuranceType" : planName.current.value,
            "status": status
        }, {
            headers: {
              'Content-Type': 'application/json',
              'Authorization': `Bearer ${token}`,
            }
          })
            .then(response => {
                alert('Plan added successfully')
                navigate(`/admindashboard/${user.username}/${user.role}`)
            })
            .catch(error => console.error(error));

    }
    const handleStatus = (e)=>{
        e.preventDefault()
        setStatus(parseInt(e.target.value))
    }
  return (
    <>
    <Navbar user={user} />
    <div className='d-flex align-items-center justify-content-center w-100'>
        <h1>Adding Insurance Plan</h1>
    </div>
    <div className='d-flex align-items-center justify-content-center w-100'>
    <div className='login mt-3'>
            <div class="card">
                <div class="card-body">
                <form>
                    <div class="mb-3">
                        <label for="exampleInputEmail1" class="form-label">Insurance Type:</label>
                        <input type="text" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" ref={planName} required/>
                    </div>
                    <div class="mb-3">
                    <label for="formFile" class="form-label">Image:</label>
                    <input class="form-control" type="file" id="formFile" />
                    </div>
                    <div class="mb-3">
                    <label for="formFile" class="form-label">Status:</label>
                    <select class="form-control" name="Status" id="Status" onChange={(e) => handleStatus(e)}>
                        <option value="2">--select--status-- </option>
                        <option value="1">Active</option>
                        <option value="0">Inactive</option>
                    </select>
                    </div>
                    <button type="submit" class="btn btn-primary w-100" onClick={(e)=>handleSubmit(e)}>Submit</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
    </>
  )
}

export default InsurancePlan