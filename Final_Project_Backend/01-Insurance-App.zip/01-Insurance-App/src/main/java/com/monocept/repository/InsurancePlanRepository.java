package com.monocept.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.monocept.entity.InsurancePlan;

public interface InsurancePlanRepository extends JpaRepository<InsurancePlan, Integer>{

}
