package com.monocept.service;


import com.monocept.entity.User;

public interface IUserService{

	public User getUser(String username);
	public User getUser(int id);
	public User saveUser(User user);
}
