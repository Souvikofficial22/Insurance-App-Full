package com.monocept.entity;

public enum Status {
	ACTIVE,INACTIVE;
}
